# Employee

# Introduction

This is a simple MERN stack app that allows the user to create and read simple blogs. mainly the purpose of this app is to practice dockerizing react and node-express app using docker-compose
<br/>




## To Start the App: 
---------------------

### Download

```
```

### Configuring App



```bash
$ cd server
$ npm install
$ nodemon index.js
```

```bash
$ cd client
$ npm install
$ npm start
```

### Docker
If you have docker installed run the following in the terminal:
```bach

```
``` 
```



